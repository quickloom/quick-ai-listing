# **App Name**: ListingAI

## Core Features:

- Property Input Form: Property Input Form: Collect property details like type, location, price, size, features, and amenities through an easy-to-use form.
- AI Content Generation: AI Content Generator Tool: Utilize Gemini or OpenAI API to generate a long-form property description, short social media captions (Facebook, Instagram, LinkedIn), and SEO meta title and meta description.
- Blog Generator: AI Blog Post Generator Tool: Create blog posts like 'Top 5 reasons to invest in [City]' using AI.
- Content Display and Copy: Content Display: Display the generated content in a clear, editable format with 'Copy to Clipboard' functionality.
- Multi-language Support: Multi-language Support: Offer multi-language support using Google Translate API or similar.

## Style Guidelines:

- Primary color: Desaturated blue (#6699CC) to evoke trust and professionalism, suitable for real estate applications.
- Background color: Very light blue (#F0F8FF), creating a clean and calming backdrop.
- Accent color: Light green (#90EE90), analogous to the primary, used to highlight important actions.
- Font pairing: 'Playfair' (serif) for headlines, lending an elegant, high-end feel, paired with 'PT Sans' (sans-serif) for body text, which provides a modern look and good readability.
- Simple, mobile-friendly UI: Design a clean and responsive layout that works seamlessly on various devices.
- Clear and professional icons: Use a consistent set of icons for navigation and key features to enhance usability.